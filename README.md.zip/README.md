# 📊 Sales Performance & Business Analysis Dashboard (Excel)

A fully formula-driven Excel dashboard built entirely with native Excel features — no external tools — to demonstrate Advanced Excel and dashboarding skills for a Business Analyst / Data Analyst role.

## 📁 What's Inside

| Sheet | Purpose |
|---|---|
| **Dashboard** | KPI cards + 5 native Excel charts (Line, Bar, Horizontal Bar, Pie, Bar) |
| **Summary** | Pivot-style summary tables (Monthly, Region, Top Products, Segment, Category Margin) — all built with `SUMIFS` formulas, not hardcoded values |
| **Raw Data** | 2,500-row transactional sales dataset (formatted as an Excel Table) |

## 🛠️ Excel Skills Demonstrated

- **SUMIFS** for multi-criteria aggregation (region-wise, month-wise, category-wise revenue & profit)
- **TEXT()** formula to derive a Month key from dates for time-series grouping
- **IFERROR** for safe percentage/margin calculations
- **Excel Tables** (structured references, banded rows) on the raw data
- **Native Excel Charts**: Line chart (trend), Column charts, Horizontal bar chart, Pie chart with data labels
- **KPI card layout** using merged cells, fills, and fonts — dashboard-style presentation
- Fully **live/dynamic**: change any value in Raw Data and every KPI, table, and chart recalculates automatically

## 📈 Key KPIs

| Metric | Value |
|---|---|
| Total Revenue | ₹20.46 Cr |
| Total Profit | ₹6.62 Cr |
| Average Profit Margin | 32.4% |
| Total Orders | 2,500 |
| Return Rate | 6.4% |

## 🔍 Key Insights

- Clear **festive-season (Oct–Nov) spike** in both revenue and profit in the monthly trend chart.
- **North and South regions** are the top two revenue contributors.
- **Electronics** category has the highest profit margin among the four product categories.
- Revenue is well distributed across customer segments (Retail, Corporate, Online), with no single segment dominating — useful for diversified go-to-market planning.

## ▶️ How to Use

1. Open `Sales_Performance_Dashboard.xlsx` in Excel.
2. Go to the **Dashboard** tab to see KPIs and charts.
3. Go to **Raw Data** to see/edit the underlying transactions — all summaries and charts update automatically.
4. Go to **Summary** to see the SUMIFS-based pivot-style tables behind each chart.

## 📌 Note on Data

Data is a synthetic sample dataset created to simulate realistic retail sales, since no proprietary company dataset was available. The formulas, KPI logic, and dashboard structure are directly transferable to real business data.

---
**Author:** Purushottam Raut
📧 piyushraut9993@gmail.com | 🔗 [LinkedIn](https://www.linkedin.com/in/purushottam-raut-a75349358)
